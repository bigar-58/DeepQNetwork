For Mini Project 4: Reproducability we used the following packages:
1. gym[atari]
2. gym stable-baselines3[extra]

Downloading the above will install all of the dependecies needed to run the imports.